<?php

// llamando al iniciador
require_once "../app/initializer.php";

// iniciamos el core
new Core();
